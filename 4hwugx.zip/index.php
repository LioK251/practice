<head>
    <title>Главная - Абоба Corporation</title>
    <link rel="stylesheet" href="minimal.css">
</head>
<body>
    <header>
        <h1>Абоба Corporation</h1>
        <nav>
            <a class='focused' href='index.php'>Главная</a>
            <a href='log.php'>Логин</a>
            <a href='reg.php'>Регистрация</a>
            <a href='katalog.php'>Каталог</a>
        </nav>
    </header>
    <section>
        <h1>Главная страница</h1>
        <p>О нашей корпорации, мы делаем самые лучшие чипсеки и шашлындосы</p>
    </section>

    <footer>
        <p>@ 2025. Все права проданы, чупеп.</p>
    </footer>
</body>