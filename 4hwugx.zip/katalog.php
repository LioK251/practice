<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Каталог — Абоба Corporation</title>
    <link rel="stylesheet" href="minimal.css">
</head>
<body>
<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'jmapel';
    $conn = new mysqli($host, $user, $pass, $dbname);
    $conn->set_charset('utf8mb4');

    $selectedCategory = $_POST['category'] ?? '';
?>
<header>
    <h1>Абоба Corporation</h1>
    <nav>
        <a href='index.php'>Главная</a>
        <a href='log.php'>Логин</a>
        <a href='reg.php'>Регистрация</a>
        <a class='focused' href='katalog.php'>Каталог</a>
    </nav>
</header>

<section>
    <div class="aboba">
        <?php

        $cats = $conn->query('SELECT DISTINCT `category` FROM `category` ORDER BY `category`');
        echo "<div class='filters'>";
        echo "<form action='katalog.php' method='post' style='display:inline-block;margin:4px'>";
        echo "  <input type='submit' name='category' value='Все товары'>";
        echo "</form>";
        while ($c = $cats->fetch_assoc()) {
            $val = $c['category'];
            echo "<form action='katalog.php' method='post' style='display:inline-block;margin:4px'>";
            echo "  <input type='submit' name='category' value='".htmlspecialchars($val, ENT_QUOTES)."'>";
            echo "</form>";
        }
        echo "</div>";
        ?>
    </div>

    <div class="aboba main">
        <?php
        $where = [];
        $params = [];
        $types = '';

        if ($selectedCategory && $selectedCategory !== 'Все товары') {
            $where[] = '`category` = ?';
            $params[] = $selectedCategory;
            $types .= 's';
        }

        $sql = 'SELECT `id`, `name`, `price`, `img`, `category`, `description1`, `description2` FROM `category`';
        if ($where) {
            $sql .= ' WHERE '.implode(' AND ', $where);
        }
        $sql .= ' ORDER BY `id` DESC';

        $stmt = $conn->prepare($sql);
        if ($params) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows) {
            while ($row = $res->fetch_assoc()) {
                $img = $row['img'] && file_exists($row['img']) ? $row['img'] : 'images/image.png';
                echo "<div class='card'>";
                echo "  <img src='".htmlspecialchars($img, ENT_QUOTES)."' alt='".htmlspecialchars($row['name'], ENT_QUOTES)."'>";
                echo "  <h1>".htmlspecialchars($row['name'])."</h1>";
                echo "  <p>Категория: ".htmlspecialchars($row['category'])."</p>";
                echo "  <p>Цена: ".htmlspecialchars($row['price'])." руб.</p>";
                $desc = [];
                for ($i=1;$i<=4;$i++){
                    $k = 'description'.$i;
                    if (!empty($row[$k])) $desc[] = htmlspecialchars($row[$k]);
                }
                if ($desc) {
                    echo "<ul>";
                    foreach ($desc as $d) echo "<li>$d</li>";
                    echo "</ul>";
                }
                echo "</div>";
            }
        } else {
            echo "<p>Товары не найдены</p>";
        }
        $stmt->close();
        $conn->close();
        ?>
    </div>
</section>
<footer>
    <p>@ 2025. Все права проданы, чупеп.</p>
</footer>
</body>
</html>
