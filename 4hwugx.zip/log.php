<head>
    <title>Логин - Абоба Corporation</title>
    <link rel="stylesheet" href="minimal.css">
</head>
<body>
    <?php
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $dbname = 'jmapel';
        $conn = new mysqli($host, $user, $pass, $dbname);
        $conn->set_charset('utf8mb4');

        $selectedCategory = $_POST['reg'] ?? '';
    ?>
    <header>
        <h1>Абоба Corporation</h1>
        <nav>
            <a href='index.php'>Главная</a>
            <a class='focused' href='log.php'>Логин</a>
            <a href='reg.php'>Регистрация</a>
            <a href='katalog.php'>Каталог</a>
        </nav>
    </header>
    <section>
        <h1>Логин</h1>
        
        <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reg']) && ($_POST['reg'] == "Зарегистрироваться")) {
                $login = $_POST['login'] ?? '';
                $mail = $_POST['mail'] ?? '';
                $pass1 = $_POST['pass1'] ?? '';
                $pass2 = $_POST['pass2'] ?? '';
                $faimly = $_POST['faimly'] ?? '';
                $name = $_POST['name'] ?? '';
                $dubel_name = $_POST['dubel_name'] ?? '';

                if (!empty($login) && !empty($mail) && !empty($pass1) && !empty($pass2) && !empty($faimly) && !empty($name) && !empty($dubel_name)) {
                    if ($pass1 !== $pass2) {
                        echo '<h1 style="color: red; text-align: center;">Пароли не совпадают!1!</h1>';
                        exit;
                    }
                    
                    $conn = mysqli_connect('localhost', 'root', '', 'jmapel');
                    if (!$conn) {
                        die('db error nigger' . mysqli_connect_error());
                    }

                    $stmt = mysqli_prepare($conn, "SELECT 1 FROM reg WHERE login = ? OR mail = ? LIMIT 1");
                    mysqli_stmt_bind_param($stmt, "ss", $login, $mail);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);

                    if (mysqli_stmt_num_rows($stmt) > 0) {
                        echo '<h1 style="color: red; text-align: center;">Такой логин/почта уже существует!1!</h1>';
                        mysqli_stmt_close($stmt);
                        mysqli_close($conn);
                        exit;
                    }
                    mysqli_stmt_close($stmt);

                    $query = "INSERT INTO reg (`login`,`mail`,`pass`,`status`,`faimly`,`name`,`dubel_name`) VALUES ('$login','$mail','$pass1','0','$faimly','$name','$dubel_name')";
                    $result = mysqli_query($conn, $query);
                    echo '<h1 style="color: #2faa73; text-align: center;">Регистрация успешная!!!1!</h1>';
                } else {
                    echo '<h1 style="color: red; text-align: center;">Не все поля заполнены!1!</h1>';
                }
            }
        ?>
        <table align="center">
            <form action='log.php' method='post'>
                <tr>
                    <td>Введите логин</td>
                    <td><input type="text" name="login_or_email" placeholder="Логин" require></td>
                </tr>
                <tr>
                    <td>Введите пароль</td>
                    <td><input type="password" name="password" placeholder="Пароль" require></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="do_login" value="Войти" require></td>
                </tr>
        </table>
    </section>
    <footer>
        <p>@ 2025. Все права проданы, чупеп.</p>
    </footer>
</body>